import 'package:flutter/material.dart';
import 'package:homework4_1/screenui/freecourse.dart';
import 'package:homework4_1/screenui/paidcourse.dart';
import 'screenui/listdraw.dart';
import 'screenui/my_header_drawer.dart';
class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: SingleChildScrollView(
          child:Container(
            child: Column(children: [
              Myheaderdrawer(),
               ListDraw(),],),
          )
          ,),
      ),
      appBar: AppBar(title:Text('Home',
        style: TextStyle(color: Colors.black,
            fontWeight: FontWeight.bold),
      ),
      centerTitle: true,
        backgroundColor: Color(0xffe38ab8),elevation: 5,
        leading: Builder(
          builder: (context){
            return IconButton(onPressed: ()=>Scaffold.of(context).openDrawer(), icon: Icon(Icons.dehaze_rounded,color: Colors.black,));
          },
        )
      )
      ,body: SingleChildScrollView(child:

          Column(
        children: [ SizedBox(height:7,),
         Row(
           mainAxisAlignment: MainAxisAlignment.spaceBetween,
           children: [Text('Checkout our Demo',
           style: TextStyle(color: Colors.black) ,),
            Icon(Icons.arrow_forward_ios ,color: Colors.grey,)
         ],),
          SizedBox(height: 2,),
          Container(
            width: 250,
            height: 150,
            child:ListView.builder(scrollDirection: Axis.horizontal,
                itemCount: 5,
                itemBuilder: (contex ,i){
              return Container(
                    width: 250,
                height: 160,
                child: Image.asset('assets/list.png',fit: BoxFit.fill,),);
            }) ,),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [Text('Our Free Courses ',
              style: TextStyle(color: Colors.black) ,),
              Icon(Icons.arrow_forward_ios ,color: Colors.grey,)
            ],),SizedBox(height: 10,),
              freecourse(),SizedBox(height:5,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [Text('our paid Courses ',
              style: TextStyle(color: Colors.black) ,),
              Icon(Icons.arrow_forward_ios ,color: Colors.grey,)
            ],),SizedBox(height:3,),
          paid()
        ],
          ),)
    );
  }

}
