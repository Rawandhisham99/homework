import 'package:flutter/material.dart';
class ListDraw extends StatefulWidget {
  const ListDraw({Key? key}) : super(key: key);

  @override
  State<ListDraw> createState() => _ListDrawState();
}

class _ListDrawState extends State<ListDraw> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(children: [
        ListTile(
            onTap: (){},
            title: Text('Home',
          style: TextStyle(fontSize:15,
          fontWeight: FontWeight.bold,
          color:Colors.black,),),leading:Icon(Icons.home,color: Color(0xffe38ab8)))
          ,ListTile(
          onTap: (){Navigator.of(context).pushNamed('course');},
          title: Text('Course',
          style: TextStyle(fontSize:15,
          fontWeight: FontWeight.bold,
          color:Colors.black,),),
          leading:Icon(Icons.book_online_sharp,color: Color(0xffe38ab8))),
             ListTile(
                  onTap: (){},
                  title: Text('News',
                  style: TextStyle(fontSize:15,
                  fontWeight: FontWeight.bold,
                  color:Colors.black,),),
                  leading:Icon(Icons.book_online_sharp,color: Color(0xffe38ab8))),
        ListTile(
          onTap: (){},
               title: Text('Prouduct',
                 style: TextStyle(fontSize:15,
                fontWeight: FontWeight.bold,
                  color:Colors.black,),),
            leading:Icon(Icons.shopping_bag,color: Color(0xffe38ab8))),
        ListTile(
            onTap: (){},
            title: Text('Cart',
              style: TextStyle(fontSize:15,
                fontWeight: FontWeight.bold,
                color:Colors.black,),),
            leading:Icon(Icons.shopping_cart_outlined,color: Color(0xffe38ab8))),
        ListTile(
            onTap: (){},
            title: Text('My Profile',
              style: TextStyle(fontSize:15,
                fontWeight: FontWeight.bold,
                color:Colors.black,),),
            leading:Icon(Icons.person,color: Color(0xffe38ab8))),
        ListTile(
            onTap: (){},
            title: Text('Setting',
              style: TextStyle(fontSize:15,
                fontWeight: FontWeight.bold,
                color:Colors.black,),),
            leading:Icon(Icons.settings,color: Color(0xffe38ab8))),
        ListTile(
            onTap: (){},
            title: Text('LogOut',
              style: TextStyle(fontSize:15,
                fontWeight: FontWeight.bold,
                color:Colors.black,),),
            leading:Icon(Icons.logout,color: Color(0xffe38ab8))),



      ],),


          );
  }
}
