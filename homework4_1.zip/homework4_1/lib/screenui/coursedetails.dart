import'package:flutter/material.dart';
import 'package:readmore/readmore.dart';

    class course extends StatefulWidget {

      @override
      State<course> createState() => _courseState();
    }

    class _courseState extends State<course> {
      String cont="Relax and do whatever fit with your design process Dont set alot of restrictive hard -and-fast ruls Use filler text where it helps your design process .but use real content if you ve got it as long as it dosent  distract and show down your desin process use real ";

      @override
      Widget build(BuildContext context) {
        return Scaffold(appBar:AppBar(
          backgroundColor: Color(0xffe38ab8),
          title: Text("Course Detail" ,style:TextStyle(color:Colors.black,fontWeight:FontWeight.bold),),
          centerTitle: true,
          elevation: 5,
          leading: Icon(Icons.arrow_back_ios,color: Colors.black,),
        ),body:SingleChildScrollView(
          padding: EdgeInsets.only(left: 15),
          scrollDirection: Axis.horizontal,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [SizedBox(height: 15,),
                Text('Diploma of Information Technology Network',style: TextStyle(color: Colors.black), )
                ,Row(children: [
                  Text('By',style: TextStyle(color: Colors.black),),
                  Text('Gilberto S.Osbne',style: TextStyle(color: Colors.grey)),
                  Text('36Reviews') ,InkWell( onTap: (){},child:Text('(View All)',style: TextStyle(color:Color(0xfff5c842)),),
                 ), ],
                ),SizedBox(height:5,),
                Row(children: [
                    Text('Start On',style: TextStyle(color: Colors.black),),
                    Text('05 Feb2020',style: TextStyle(color: Colors.grey)),
                    SizedBox(width: 5,),
                    Text('27 lession',style: TextStyle(color: Colors.black),),
                  ],
                ),
                Text('75.00 KWD',style: TextStyle(color:Color(0xfff5c842)))
                ,SizedBox(height: 20,),
                Text('About this Course',style: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),)
                ,Container(height:150,
                  width:350,
                  child: ReadMoreText(cont ,
                    trimLines:4,
                    textAlign:TextAlign.justify,
                    trimMode: TrimMode.Line,
                    trimCollapsedText: 'Show more',
                    trimExpandedText: 'Show less',
                    moreStyle: TextStyle(fontSize: 14,color: Colors.black),
                    lessStyle: TextStyle(fontSize: 14, color: Colors.black),
                    style:TextStyle(color: Colors.grey), ),),
                Text('Courses',style: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),),

            Container(
              child: Column(children: [Card(child:Row( mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text('Lissen 01',style:TextStyle(color:Color(0xfff5c842),fontSize:10) ,),
                  Text('Introdiction',style: TextStyle(color: Colors.black),)

                  ,Image.asset('assets/play.png')
                ],),),
                Card(
                  child:Row( mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text('Lissen 02',style:TextStyle(color:Color(0xfff5c842),fontSize:10), ),SizedBox(width: 5,),
                      Text('Basic intro of Online Network ',style: TextStyle(color: Colors.black),)

                      ,Image.asset('assets/play.png')
                    ],),),
                Card(
                  child:Row( mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text('Lissen 03',style:TextStyle(color:Color(0xfff5c842),fontSize:10) ,),
                      Text('Information of Online Networking ',style: TextStyle(color: Colors.black),)

                      ,Image.asset('assets/play.png')
                    ],),),
              ],
              )



            )

                ,

         ] ),
          ),
        );
      }
    }
