import 'package:carousel_slider/carousel_slider.dart';
import'package:flutter/material.dart';
class carousel extends StatefulWidget {
   List<String> img;
  carousel({required this.img});
  @override
  State<carousel> createState() => _carouselState();
}

class _carouselState extends State<carousel> {

int _current=0;
  @override
  Widget build(BuildContext context) {

    final List<Widget> imgslider=
        widget.img.map((item)=>Container(
          margin: EdgeInsets.symmetric(horizontal: 7.0),
          child:ClipRect
            (child :Image.asset(item,fit:BoxFit.cover,width:250),
    ),)
    ).toList();
    return Column(children: [
      CarouselSlider(items:imgslider, options: CarouselOptions(
      aspectRatio: 2.0,
      onPageChanged: (index ,reason){
        setState((){
        _current =index;
        });
      })
    ),Row(mainAxisAlignment: MainAxisAlignment.center,
        children: widget.img.map((asset){
          int index=widget.img.indexOf(asset);
          return Container(
            width: 8,height: 8,
            margin: EdgeInsets.symmetric(vertical: 10.0,horizontal: 3.0),
            decoration:BoxDecoration(shape: BoxShape.circle,
            color: _current==index ?Color.fromRGBO(245, 66, 239 ,0.9)
            :Color.fromRGBO(0, 0,0 ,0.7)
            )
            ,);
        }).toList(),

      )
    ],
    );
    }

  }