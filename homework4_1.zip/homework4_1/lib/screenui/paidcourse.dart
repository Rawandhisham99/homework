import 'package:flutter/material.dart';
class paid extends StatefulWidget {
  const paid({Key? key}) : super(key: key);

  @override
  State<paid> createState() => _paidState();
}

class _paidState extends State<paid> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 280,
      height: 150,
      child:ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: 2,
          itemBuilder: (contex ,i){
            return Row(children: [Card(
              child:Column(children: [
                Image.asset('assets/social.png'),
                Text('Social media market ',style:TextStyle(color:Color(0xfff5c842),fontWeight: FontWeight.bold,fontSize:10) ,)
              ],),),
              Card(child:Column(children: [
                Image.asset('assets/word.png'),
                Text('Social media Influncer ',style:TextStyle(color:Color(0xfff5c842),fontWeight: FontWeight.bold,fontSize:10) ,)
              ],),),
              Card(child:Column(children: [
                Image.asset('assets/tel.png'),
                Text('Biolge the since ',style:TextStyle(color:Color(0xfff5c842),fontWeight: FontWeight.bold,fontSize:10) ,)
              ],),)

            ],);
          }

      ) ,
    );
  }
}
