import 'package:flutter/material.dart';
class freecourse extends StatefulWidget {
  const freecourse({Key? key}) : super(key: key);

  @override
  State<freecourse> createState() => _freecourseState();
}

class _freecourseState extends State<freecourse> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 280,
      height: 150,
      child:ListView.builder(
          scrollDirection: Axis.horizontal,
        itemCount: 2,
          itemBuilder: (contex ,i){
            return Row(children: [Card(
              child:Column(
                children: [
              Image.asset('assets/card1.png'),
              Text('Arts And Humanties ',style:TextStyle(color:Color(0xfff5c842),fontWeight: FontWeight.bold,fontSize:10) ,)
            ],),),
              Card(child:Column(children: [
                Image.asset('assets/lap.png'),
                Text('Computer Scince ',style:TextStyle(color:Color(0xfff5c842),fontWeight: FontWeight.bold,fontSize:10) ,)
              ],),),
              Card(child:Column(children: [
                Image.asset('assets/eco.png'),
                Text('Econem and fin ',style:TextStyle(color:Color(0xfff5c842),fontWeight: FontWeight.bold,fontSize:10) ,)
              ],),)
              
            ],);
          }

          ) ,

      );

  }
}
