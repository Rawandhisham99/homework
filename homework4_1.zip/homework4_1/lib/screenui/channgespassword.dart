import 'package:flutter/material.dart';
class chanpass extends StatefulWidget {
  const chanpass({Key? key}) : super(key: key);

  @override
  State<chanpass> createState() => _chanpassState();
}

class _chanpassState extends State<chanpass> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title:Text('Change Password',
          style: TextStyle(color: Colors.black,
              fontWeight: FontWeight.bold,fontSize: 15),
        ),
            centerTitle: true,
            backgroundColor: Color(0xffe38ab8),elevation: 5,
            leading: Builder(
              builder: (context){
                return IconButton(onPressed: ()=>Scaffold.of(context), icon: Icon(Icons.arrow_back_ios_outlined,color: Colors.black,));
              },
            )

        )
            ,body: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [Text('Enter your new Password below.',
        style: TextStyle(color: Colors.black,
          fontWeight: FontWeight.bold,fontSize:10),),
        TextField(
          keyboardType: TextInputType.visiblePassword,
          obscureText: true,
          decoration: InputDecoration(border: OutlineInputBorder(borderRadius:BorderRadius.circular(20),
              borderSide: BorderSide(color: Colors.grey,width: 1.5)
          ),
            labelText:'Current Password',
            hintText: "Current Password",
          ),
        ),SizedBox(height: 5,),
      TextField(
        keyboardType: TextInputType.visiblePassword,
        obscureText: true,
        decoration: InputDecoration(border: OutlineInputBorder(borderRadius:BorderRadius.circular(20),
            borderSide: BorderSide(color: Colors.grey,width: 1.5)
        ),
          labelText:' New Password',
          hintText: "New Password",
        ),),SizedBox(height: 5,),
        TextField(
          keyboardType: TextInputType.visiblePassword,
          obscureText: true,
          decoration: InputDecoration(border: OutlineInputBorder(borderRadius:BorderRadius.circular(20),
              borderSide: BorderSide(color: Colors.grey,width: 1.5)
          ),
            labelText:' Conform New Password',
            hintText: " Conform  New Password",
          ),),
        SizedBox(height: 5,),
        ElevatedButton(onPressed: (){

        }, child: Text("SAVE"),
          style:ElevatedButton.styleFrom(
            primary:Color(0xffe38ab8),
            minimumSize: Size(double.infinity,50),
            shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          ),),

    ],),
    );
  }
}
