import 'package:carousel_slider/carousel_slider.dart';
import'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import 'carouselwithdot.dart';
class proudect extends StatefulWidget {
  const proudect({Key? key}) : super(key: key);

  @override
  State<proudect> createState() => _proudectState();
}

class _proudectState extends State<proudect> {
  int  active=0;
  int  b=0;
       final List<String> img=['assets/mag.png','assets/mag.png','assets/mag.png'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xfffaa2d6),
          title: Text("Product Detail" ,style:TextStyle(color:Colors.black,fontWeight:FontWeight.bold),),actions: [Icon(Icons.shopping_cart_outlined,color: Colors.black)],
          centerTitle: true,
          elevation: 5,
          leading: Icon(Icons.arrow_back_ios,color: Colors.black),

        ),  body:SingleChildScrollView(child: Container(padding:EdgeInsets.only(left: 10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
             children: [
            SizedBox(height: 20,),
               carousel(img:img),
              SizedBox(height: 4,),
               Text('The Earth Ceramic Coffee Mug',style: TextStyle(fontWeight:FontWeight.bold,color: Colors.black),),
                 SizedBox(height:4,),
                Text('280KWG',style: TextStyle(color:Color(0xfff5c842),fontFamily: 'TiroDevanagariSanskrit'),),
               SizedBox(height:4,), Card(
                   child:Row(children: [IconButton(onPressed: (){
                     b=b-1;
                   }, icon:Icon(Icons.remove),color: Colors.grey,)
                     ,Text('$b',style: TextStyle(color:Colors.black),),
                     IconButton(onPressed: (){
                       b=b+1;
                     }, icon:Icon(Icons.add),color: Colors.grey,)
                   ],)),
               Text('About Prouduct',style: TextStyle(fontWeight:FontWeight.bold,
                   color: Colors.black,
                   fontFamily: 'TiroDevanagariSanskrit')),
      Container(
               margin:EdgeInsets.only(left: 8.0),
                 child: RichText(text: TextSpan(children: <TextSpan>[
                 TextSpan(text:'It is along establish fact that a reader will bedistercted  by the readabel conteent obwhen lookingfjfjkhkjfkdh.',
                     style: TextStyle(color: Colors.grey,fontSize: 15) ),
                   TextSpan(text:'                                                '),
                   TextSpan(text:'The  Point of using lorem Ipsum is that it has a more-or-less  normal distrbuet of letter as oppset to uiseng controllr readable English',
                       style: TextStyle(color: Colors.grey,fontSize: 15) ),
               ]
               )
               ),
      ), SizedBox(height: 15,),
               ElevatedButton(

                 onPressed: (){},child:
            Text("ADD TO CART",style:TextStyle(fontWeight:FontWeight.bold,color: Colors.black)),style:ElevatedButton.styleFrom(
                 primary:Color(0xfffaa2d6),
                 padding: EdgeInsets.symmetric(horizontal: 90.0,vertical: 14.0),
                 shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(50.0))
             ),
            ),
    ]

        ,)
      ,),

    )
    );
    }}