import 'package:flutter/material.dart';
class Myheaderdrawer extends StatefulWidget {
  const Myheaderdrawer({Key? key}) : super(key: key);

  @override
  State<Myheaderdrawer> createState() => _MyheaderdrawerState();
}

class _MyheaderdrawerState extends State<Myheaderdrawer> {
  @override
  Widget build(BuildContext context) {
    return
      Container(
      color:Colors.white,
          width: double.infinity,
      height: 200,
      padding: EdgeInsets.only(top: 20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [Container(
          margin: EdgeInsets.only(bottom: 10.0),
          height: 70,decoration: BoxDecoration(shape: BoxShape.circle,
        image:DecorationImage(image: AssetImage('assets/draw.png'))),
        )
          ,Text('Rachelle D.Mchacl ',style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold,
          fontSize: 15.0))
        ],
      ),

    );
  }
}
