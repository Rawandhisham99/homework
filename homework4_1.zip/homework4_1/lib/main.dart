import 'package:flutter/material.dart';
import 'package:homework4_1/Home.dart';
import 'package:homework4_1/screenui/coursedetails.dart';
import 'package:homework4_1/screenui/prouduct.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      home: Home(),
      routes: {
        'course':(context){
          return proudect();
        }
      },

    );
  }
}
