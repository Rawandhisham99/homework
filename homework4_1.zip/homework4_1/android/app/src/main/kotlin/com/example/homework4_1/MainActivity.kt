package com.example.homework4_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
